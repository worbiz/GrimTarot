/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "fa0efba8fd720c5056e0ce7c490e0630"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e20ba7a93fd0aa5dafe83a6665a41c50"
  }, {
    "url": "pwa-192x192.png",
    "revision": "7a309d6f0b9269aaa52166daf261a283"
  }, {
    "url": "index.html",
    "revision": "40211bd81300133783483b577d29bf69"
  }, {
    "url": "icon.svg",
    "revision": "711c38f40c3eb21f3a09ae9b64b761c3"
  }, {
    "url": "favicon.ico",
    "revision": "552f81d5e0aaa49b59a75053ae0d81dc"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "74e3cbeb34135d09e99ab82bcf2e3aff"
  }, {
    "url": "assets/index-B9iHD8uq.js",
    "revision": null
  }, {
    "url": "assets/index-B1Q9FzJR.css",
    "revision": null
  }, {
    "url": "assets/grim_thoth_wands_1788024749947-SIxdxn67.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_universe_1788023341342-CLt5PcB9.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_tower_1788024570560--beIgfIT.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_swords_1788024778620-Col-miFQ.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_sun_1788024626629-DDZ1_68C.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_star_1788024608769-BkOyhrou.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_priestess_1788023416965-DCAWmPvU.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_moon_1788024597001-D2A4l7yC.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_magus_1788023313616-BaloP_Ro.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_lust_1788023403490-B7NXX1RZ.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_lovers_1788024666001-C0YVs0bp.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_hierophant_1788024682645-HLwFRvzF.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_hermit_1788024653113-D60KCeoV.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_hanged_man_1788024736881-BC729jqB.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_fortune_1788024721171-B-q2Wqc5.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_fool_1788023353854-sy7sQa_6.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_empress_1788024542362-CpxZ_ETn.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_emperor_1788024524957-TGi3hlWf.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_disks_1788024791569-By2woJD7.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_devil_1788024583863-DU-e8Fy2.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_death_1788024556900-BIxpkZCl.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_cups_1788024764574-porGCNIR.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_chariot_1788024695044-D-Hj7cVm.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_back_1788023370734-COLaMjt5.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_art_1788023327937-CnC1Mnvd.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_aeon_1788024639461-B52UYfX9.jpg",
    "revision": null
  }, {
    "url": "assets/grim_thoth_adjustment_1788024707917-DBVivaaC.jpg",
    "revision": null
  }, {
    "url": "assets/aistudio/rhodon_dh_chosen_mason_f6d06090.jpeg",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "74e3cbeb34135d09e99ab82bcf2e3aff"
  }, {
    "url": "favicon.ico",
    "revision": "552f81d5e0aaa49b59a75053ae0d81dc"
  }, {
    "url": "icon.svg",
    "revision": "711c38f40c3eb21f3a09ae9b64b761c3"
  }, {
    "url": "pwa-192x192.png",
    "revision": "7a309d6f0b9269aaa52166daf261a283"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e20ba7a93fd0aa5dafe83a6665a41c50"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "fa0efba8fd720c5056e0ce7c490e0630"
  }, {
    "url": "manifest.webmanifest",
    "revision": "a86ffa46edd68414367a7bfb7aae9309"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
