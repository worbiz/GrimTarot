var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_url = require("url");
var import_vite = require("vite");
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_meta = {};
import_dotenv.default.config();
var __filename = (0, import_url.fileURLToPath)(import_meta.url);
var __dirname = import_path.default.dirname(__filename);
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  app.post("/api/tarot-ai-interpretation", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
        return res.json({
          interpretation: "Die Legung wurde lokal offline ausgewertet. F\xFCr tiefere KI-Inspirationen konfigurieren Sie bitte den GEMINI_API_KEY in den AI Studio Einstellungen."
        });
      }
      const { spreadName, question, drawnCards } = req.body;
      const ai = new import_genai.GoogleGenAI({ apiKey });
      const prompt = `Du bist ein tiefgr\xFCndiger, empathischer Experte f\xFCr das Aleister Crowley Thoth Tarot (Buch Thoth, Lady Frieda Harris).
Erstelle eine pr\xE4zise, faszinierende Interpretation in deutscher Sprache f\xFCr folgende Tarot-Legung:

Legung: ${spreadName}
Frage / Thema: ${question || "Allgemeiner Lebensfokus"}

Gezogene Karten:
${JSON.stringify(drawnCards, null, 2)}

Achte besonders auf:
1. Das Zusammenspiel der Crowley Thoth Symbolik (Elemente, Atu, Astrologie, Hofkarten).
2. Konkrete, lebensnahe Ratschl\xE4ge ohne Schwarzmalerei.
3. Wenn Karten 'isReversed: true' (auf dem Kopf stehend) sind: Beachte, dass dies signalisiert, dass die Energie blockiert, verz\xF6gert oder nach innen gerichtet ist. Es ist kein rein negatives Omen, sondern zeigt eine Herausforderung oder ungenutzte Chance an.
4. Halte die Zusammenfassung pr\xE4gnant (ca. 150-250 W\xF6rter), tiefgr\xFCndig und inspirierend.`;
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt
      });
      const interpretationText = response.text || "Keine Antwort generiert.";
      res.json({ interpretation: interpretationText });
    } catch (error) {
      console.error("Error generating AI tarot interpretation:", error);
      res.status(500).json({
        interpretation: "Es ist ein Fehler bei der Online-Interpretation aufgetreten. Ihre Legung bleibt lokal im Tagebuch vollst\xE4ndig ausgewertet."
      });
    }
  });
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", app: "GrimTarot" });
  });
  app.get("/downloads/:filename", (req, res, next) => {
    const filename = import_path.default.basename(req.params.filename);
    const pubFile = import_path.default.join(process.cwd(), "public", "downloads", filename);
    const distFile = import_path.default.join(process.cwd(), "dist", "downloads", filename);
    const targetFile = import_fs.default.existsSync(pubFile) ? pubFile : distFile;
    if (import_fs.default.existsSync(targetFile)) {
      return res.download(targetFile, filename);
    }
    next();
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`GrimTarot server listening on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
